package com.team08.arlingtonauto;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ViewReservationAdapter extends ArrayAdapter<ReservationDbModel> {
    private List<ReservationDbModel> l = new ArrayList<ReservationDbModel>();
    private Context mContext;


    public ViewReservationAdapter(@NonNull Context context, int resource, @SuppressLint("SupportAnnotationUsage") @LayoutRes List<ReservationDbModel> list) {
        super(context, 0, list);
        mContext = context;
        l = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View listviewRow = convertView;
        if (listviewRow == null)
            listviewRow = LayoutInflater.from(mContext).inflate(R.layout.view_reservation_row, parent, false);
        ReservationDbModel reservationDbModel = l.get(position);


        TextView carName = (TextView) listviewRow.findViewById(R.id.textView_carName_view_rsv);

        carName.setText("Car Name: "+reservationDbModel.getCarName());
        TextView reservationID = (TextView) listviewRow.findViewById(R.id.textView_reservation_id);

            reservationID.setText("Reservation_ID"+Integer.toString(reservationDbModel.getReservationID()));


        TextView finalPrice = (TextView) listviewRow.findViewById(R.id.textView_CarFinalPrice);
        finalPrice.setText("Final Price:  $ "+reservationDbModel.getFinalPrice());
        return listviewRow;

    }

}
