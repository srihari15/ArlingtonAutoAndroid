package com.team08.arlingtonauto;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class SpecificReservationActivity extends AppCompatActivity {
    SQLiteDatabase db;
    Cursor cursor;
    ReservationDbManager reservationDbManager;
    private int reservationID;
    private TextView reservationIDTextView;
    private TextView carNameTextView;
    private TextView finalPriceTextView;
    private TextView ReservationDatesTextView;
    private TextView isActiveTextView;
    private int isActive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specific_reservation);
        reservationID = getIntent().getIntExtra("EXTRA_RESERVATION_ID",0);
        reservationDbManager = new ReservationDbManager(this);
        db = reservationDbManager.getReadableDatabase();
        String carName = "",fp = "",sd = "",ed = "";

        cursor = reservationDbManager.selectSpecificReservation(db,reservationID);
        if(cursor.moveToFirst()){
            do{
            carName = cursor.getString(cursor.getColumnIndex("CarName"));
            fp = cursor.getString(cursor.getColumnIndex("FinalPrice"));
            sd = cursor.getString(cursor.getColumnIndex("RsvStartDate"));
            ed = cursor.getString(cursor.getColumnIndex("RsvEndDate"));
            isActive = cursor.getInt(6);
        }while (cursor.moveToNext());
    }
        reservationIDTextView = (TextView)findViewById(R.id.textView_ReservationID);
        reservationIDTextView.setText("ReservationID: "+Integer.toString(reservationID));
        carNameTextView = (TextView)findViewById(R.id.textView_car_name_specificreservation);
        carNameTextView.setText("CAR NAME: "+carName);
        finalPriceTextView = (TextView)findViewById(R.id.textView_finalprice_paid);
        finalPriceTextView.setText("Final price paid: $"+fp);
        ReservationDatesTextView = (TextView)findViewById(R.id.textView_Reservation_dates);
        ReservationDatesTextView.setText("From "+sd+" to:"+ed);
        isActiveTextView = (TextView)findViewById(R.id.textView_rsvIsActive);

        if(isActive ==1)
            isActiveTextView.setText("Reservation status: Active");
        else
            isActiveTextView.setText("Reservation Status: Cancelled");

    }
    public void onClickCancelReservation(View view){
        new AlertDialog.Builder(this)
                .setTitle("Cancel Reservation")
                .setMessage("Do you really want to Cancel this reservation?")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whichButton) {
                        //Toast.makeText(MainActivity.this, "Yaay", Toast.LENGTH_SHORT).show();
                        reservationDbManager.cancelReservation(reservationID);
                        Toast.makeText(getApplicationContext(),"Reservation cancelled",Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(),ViewReservationActivity.class);
                        startActivity(intent);
                    }})
                .setNegativeButton(android.R.string.no, null).show();



    }
    public void logout(View view) {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Do you really want to logout?")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whichButton) {
                        //Toast.makeText(MainActivity.this, "Yaay", Toast.LENGTH_SHORT).show();
                        //reservationDbManager.cancelReservation(reservationID);
                        Toast.makeText(getApplicationContext(), "Logout Success", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    }
                })
                .setNegativeButton(android.R.string.no, null).show();
    }
}
