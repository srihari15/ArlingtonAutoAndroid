package com.team08.arlingtonauto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ReserveCarActivity extends AppCompatActivity {
    private TextView carNameTextView;
    private ImageView carImageView;
    private TextView carCapacityTextView;
    private TextView carBasePriceTextView;
    private String carName;
    private int carImage;
    private int capacity;
    private String carBasePrice;
    private EditText fromDate;
    private EditText fromTime;
    private EditText toDate;
    private EditText toTime;
    private CheckBox gps;
    private CheckBox onStar;
    private CheckBox siriusXM;
    private String userName;



    SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
    private static final Map<String, Double> weekEndPrices;
    static
    {
        weekEndPrices = new HashMap<String, Double>();
        weekEndPrices.put("Smart",37.99);
        weekEndPrices.put("Economy",44.99);
        weekEndPrices.put("Compact",49.99);
        weekEndPrices.put("Intermediate",50.99);
        weekEndPrices.put("Standard",53.99);
        weekEndPrices.put("FullSize",57.99);
        weekEndPrices.put("SUV",64.99);
        weekEndPrices.put("MiniVan",64.99);
        weekEndPrices.put("UltraSports",204.99);

    }
    private static final Map<String, Double> weeklyPrices;
    static
    {
        weeklyPrices = new HashMap<String, Double>();
        weeklyPrices.put("Smart",230.93);
        weeklyPrices.put("Economy",279.93);
        weeklyPrices.put("Compact",314.93);
        weeklyPrices.put("Intermediate",321.93);
        weeklyPrices.put("Standard",342.93);
        weeklyPrices.put("FullSize",370.93);
        weeklyPrices.put("SUV",419.93);
        weeklyPrices.put("MiniVan",419.93);
        weeklyPrices.put("UltraSports",1399.93);

    }


    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserve_car);
        carNameTextView = (TextView)findViewById(R.id.textView_reserve_car_name);
        carImageView = (ImageView)findViewById(R.id.imageView_reserve_car);
        carCapacityTextView = (TextView)findViewById(R.id.textView_reserve_car_capacity);
        carBasePriceTextView = (TextView)findViewById(R.id.textView_reserve_car_base_price);
        carName = getIntent().getStringExtra("EXTRA_CAR_NAME");
        carImage = getIntent().getIntExtra("EXTRA_CAR_IMAGE",R.drawable.compact);
        capacity = getIntent().getIntExtra("EXTRA_CAR_CAPACITY",4);
        carBasePrice = getIntent().getStringExtra("Extra_CAR_BASE_PRICE");
        userName = getIntent().getStringExtra("EXTRA_USER_NAME");
        carNameTextView.setText(carName);
        carImageView.setImageResource(carImage);
        carCapacityTextView.setText(Integer.toString(capacity));
        carBasePriceTextView.setText(carBasePrice);
        fromDate = (EditText)findViewById(R.id.editText_from_date_r);
        fromTime = (EditText)findViewById(R.id.editText_from_time_r);
        toDate = (EditText)findViewById(R.id.editText_to_date_r);
        toTime = (EditText)findViewById(R.id.editText_to_time_r);
        gps = (CheckBox)findViewById(R.id.checkBox);
        onStar = (CheckBox)findViewById(R.id.checkBox2);
        siriusXM = (CheckBox)findViewById(R.id.checkBox3);

        //boolean extras[] = {gps.isChecked(),onStar.isChecked(),siriusXM.isChecked()};




    }
    private Date[] dateParser(String d1,String d2) throws ParseException{
        Date fdTd[]={format.parse(d1),format.parse(d2)};
        return fdTd;

    }
    public void onClickCheckout(View view) {
        double finalPrice = 0.0;
        String fd = fromDate.getText().toString();
        String ft = fromTime.getText().toString();
        String td = toDate.getText().toString();
        String tt = toTime.getText().toString();
        String cap = carCapacityTextView.getText().toString();
        boolean extras[] = {gps.isChecked(),onStar.isChecked(),siriusXM.isChecked()};
        try {
            Date dateArray[] = dateParser(fromDate.getText().toString(), toDate.getText().toString());
            finalPrice = calculatePrice(dateArray[0],dateArray[1],extras);
        }
        catch (ParseException e){
            e.printStackTrace();

        }
        Intent intent = new Intent(this,ConfirmReservationActivity.class);
        intent.putExtra("EXTRA_CAR_NAME",carName);
        intent.putExtra("EXTRA_CAR_CAPACITY_CNF",cap);
        intent.putExtra("EXTRA_FINAL_PRICE",finalPrice);
        intent.putExtra("EXTRA_CAR_IMAGE",carImage);
        intent.putExtra("EXTRA_ADD_ONS",extras);
        intent.putExtra("EXTRA_FROM_DATE_CNF",fd);
        intent.putExtra("EXTRA_FROM_TIME_CNF",ft);
        intent.putExtra("EXTRA_TO_DATE_CNF",td);
        intent.putExtra("EXTRA_TO_TIME_CNF",tt);
        intent.putExtra("EXTRA_USER_NAME",userName);
        startActivity(intent);



    }
    private double calculatePrice(Date date1,Date date2,boolean extras[]){
        int noOfWeekDay = 0;
         int noOfWeekEndDays = 0;
         int noofWeeks = 0;
        Calendar startCal = Calendar.getInstance();
        startCal.setTime(date1);

        Calendar endCal = Calendar.getInstance();
        endCal.setTime(date2);

        int diffInDays = (int)( (date2.getTime() - date1.getTime())
                / (1000 * 60 * 60 * 24) );

        System.out.println("Total No of days  between " + diffInDays);
        noofWeeks = diffInDays/7 ;


        startCal.add(Calendar.DATE, 7 * noofWeeks);

        do {

            if (startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY && startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
                ++noOfWeekDay;
            }
            else
            {
                ++noOfWeekEndDays;
            }

            startCal.add(Calendar.DATE, 1);
        }while(startCal.getTimeInMillis() <= endCal.getTimeInMillis());

        System.out.println("Number of days Week " + noOfWeekDay );
        System.out.println("Number of days WeekEnd " + noOfWeekEndDays );
        System.out.println("no of weeks is " + noofWeeks);
        double finalPrice; double weekDayPrice = Double.parseDouble(carBasePrice);
        double extrasPrice = 0.0;
        if(extras[0]==true)
            extrasPrice+=3.0;
        if(extras[1]==true)
            extrasPrice+=5.0;
        if(extras[2]==true)
            extrasPrice+=7.0;
        finalPrice = weekDayPrice*noOfWeekDay + noOfWeekEndDays*(weekEndPrices.get(carName)) + noofWeeks*(weeklyPrices.get(carName)) + extrasPrice;
        finalPrice = ((finalPrice*8.25)/100) + finalPrice;
        finalPrice = Math.round(finalPrice);
        return finalPrice;







    }
}
