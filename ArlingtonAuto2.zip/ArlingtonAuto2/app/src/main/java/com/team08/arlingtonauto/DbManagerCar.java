package com.team08.arlingtonauto;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

public class DbManagerCar extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "ArlingtonAuto.db";


    public DbManagerCar(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            //db.execSQL("create table if not exists SystemUser(userName text primary key not null,password text not null,utaId text,phone text,city text,role text not null)");
            db.execSQL("create table if not exists Cars(carName text primary key not null,capacity int not null,rsvStartDate Date DEFAULT NULL,rsvEnd Date DEFAULT NULL)");
        }
        catch (SQLException e){
            e.printStackTrace();
        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists Cars");
    }
    public Cursor searchCars(SQLiteDatabase db,String fd,String ft,String td,String tt,String cap){
        db = getReadableDatabase();
        Cursor cursor;
        String query;
        if(fd.equals("")&&ft.equals("")&&td.equals("")&&tt.equals("")&&cap.equals("")) {
            query = "select * from Cars where rsvEnd IS NULL";
        }
        else if (fd.equals("")&&ft.equals("")&&td.equals("")&&tt.equals("")&&!cap.isEmpty()){
            int car_capacity = Integer.parseInt(cap);
            query = "select * from Cars where rsvEnd IS NULL and capacity>=" +car_capacity ;
        }
        else{
            query = "select * from Cars where rsvEnd IS NULL";
        }
        cursor = db.rawQuery(query, null);
        return cursor;
    }
    public void updateDateOnReservation(String carName,String sd,String ed){
        SQLiteDatabase db = getWritableDatabase();
        String query = "UPDATE  Cars set rsvStartDate = '"+sd+"'"+","+"rsvEnd = '"+ed+"'"+" WHERE carName = '"+carName+"'";
        try{
            db.execSQL(query);
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
    public Cursor AvailabeCars(SQLiteDatabase db){
        db = getReadableDatabase();
        String query = "SELECT * FROM Cars WHERE rsvEnd is NULL";
        Cursor cursor = db.rawQuery(query,null);
        return cursor;


    }
    public void clr(SQLiteDatabase db){
        db=getWritableDatabase();
        try{
            db.execSQL("UPDATE Cars set rsvStartDate = NULL,rsvEnd = NULL");
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
    public void insertData(SQLiteDatabase db){
        try {
            db.execSQL("INSERT INTO Cars(carName,capacity)values('Smart',1)");
            db.execSQL("INSERT INTO Cars(carName,capacity)values('Economy',3)");
            db.execSQL("INSERT INTO Cars(carName,capacity)values('Compact',4)");
            db.execSQL("INSERT INTO Cars(carName,capacity)values('Intermediate',4)");
            db.execSQL("INSERT INTO Cars(carName,capacity)values('Standard',5)");
            db.execSQL("INSERT INTO Cars(carName,capacity)values('FullSize',6)");
            db.execSQL("INSERT INTO Cars(carName,capacity)values('SUV',8)");
            db.execSQL("INSERT INTO Cars(carName,capacity)values('MiniVan',9)");
            db.execSQL("INSERT INTO Cars(carName,capacity)values('UltraSports',2)");
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
}
