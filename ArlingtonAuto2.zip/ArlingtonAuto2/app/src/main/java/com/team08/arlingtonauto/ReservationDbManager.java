package com.team08.arlingtonauto;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ReservationDbManager extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "ArlingtonAuto.db";


    public ReservationDbManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            //db.execSQL("create table if not exists SystemUser(userName text primary key not null,password text not null,utaId text,phone text,city text,role text not null)");
            db.execSQL("create table if not exists Reservation(ReservationID Integer primary key AUTOINCREMENT not null,UserName Text not null,CarName Text not null,RsvStartDate Date not null,RsvEndDate Date not null,FinalPrice Text not null,isActive Integer not null default 1,Foreign KEY(UserName) REFERENCES SystemUser(userName),Foreign key(CarName) REFERENCES Cars(carName))");
        }
        catch (SQLException e){
            e.printStackTrace();
        }

    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public boolean reserveCar(String userName,String carName,String sd,String ed,String finalPrice){
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            //db.execSQL("create table if not exists SystemUser(userName text primary key not null,password text not null,utaId text,phone text,city text,role text not null)");
            db.execSQL("create table if not exists Reservation(ReservationID Integer primary key AUTOINCREMENT not null,UserName Text not null,CarName Text not null,RsvStartDate Date not null,RsvEndDate Date not null,FinalPrice Text not null,isActive Integer not null default 1,Foreign KEY(UserName) REFERENCES SystemUser(userName),Foreign key(CarName) REFERENCES Cars(carName))");
        }
        catch (SQLException e){
            e.printStackTrace();
        }




    ContentValues contentValues = new ContentValues();
        contentValues.put("UserName",userName);
        contentValues.put("CarName",carName);
        contentValues.put("RsvStartDate",sd);
        contentValues.put("RsvEndDate",ed);
        contentValues.put("FinalPrice",finalPrice);
        long ins=1;
        try {
            ins = db.insert("Reservation", null, contentValues);
        }
        catch (SQLException e){
            e.printStackTrace();
        }

        if(ins==-1)
            return false;
        else
            return true;
    }
    public Cursor viewReservation(SQLiteDatabase db,String userName){
        db = getReadableDatabase();
        Cursor cursor;
        String query = "SELECT * FROM Reservation WHERE UserName = '"+userName+"'"+ "AND isActive = 1";

            cursor = db.rawQuery(query,null);

        return cursor;


    }
    public Cursor selectSpecificReservation(SQLiteDatabase db,int reservationID){
        db = getWritableDatabase();
        Cursor cursor;
        //String query = "UPDATE Reservation SET isActive = 0 WHERE ReservationID = "+reservationID;
        String query = "SELECT * FROM Reservation WHERE ReservationID = "+reservationID;
        cursor = db.rawQuery(query,null);
        return cursor;
    }
    public void cancelReservation(int reservationID){
        SQLiteDatabase db = getWritableDatabase();

        String query = "UPDATE Reservation SET isActive = 0 WHERE ReservationID = "+reservationID;
        db.execSQL(query);

    }
    public Cursor viewAllReservation(SQLiteDatabase db){
        db = getReadableDatabase();
        Cursor cursor;
        String query = "SELECT * FROM Reservation WHERE isActive = 1";
        cursor = db.rawQuery(query,null);
        return cursor;
    }
}
