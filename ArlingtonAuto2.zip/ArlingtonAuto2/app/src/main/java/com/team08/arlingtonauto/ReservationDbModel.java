package com.team08.arlingtonauto;

public class ReservationDbModel {
    private int reservationID;
    private String carName;
    private String finalPrice;

    public ReservationDbModel(int reservationID, String carName, String finalPrice) {
        this.reservationID = reservationID;
        this.carName = carName;
        this.finalPrice = finalPrice;
    }


    public int getReservationID() {
        return reservationID;
    }

    public void setReservationID(int reservationID) {
        this.reservationID = reservationID;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public String getFinalPrice() {
        return finalPrice;
    }

    public void setFinalPrice(String finalPrice) {
        this.finalPrice = finalPrice;
    }
}
