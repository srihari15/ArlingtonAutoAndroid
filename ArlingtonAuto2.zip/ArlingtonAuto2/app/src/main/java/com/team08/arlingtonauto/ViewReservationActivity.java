package com.team08.arlingtonauto;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class ViewReservationActivity extends AppCompatActivity {
    private String userName;
    private Cursor cursor;
    private ReservationDbManager reservationDbManager;
    private ListView listView;
    SQLiteDatabase db;
    ViewReservationAdapter viewReservationAdapter;
    private boolean fromManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_reservation);
        userName = getIntent().getStringExtra("EXTRA_USER_NAME");
        if(userName==null){
            userName = getIntent().getStringExtra("FROM_CONFIRM");
        }
        fromManager = getIntent().getBooleanExtra("FROM_THE_MANAGER",false);
        reservationDbManager = new ReservationDbManager(this);
        listView = (ListView)findViewById(R.id.view_reservation_main_list);
        db = reservationDbManager.getReadableDatabase();
        if(fromManager==true){
            cursor = reservationDbManager.viewAllReservation(db);
        }
        else {
            cursor = reservationDbManager.viewReservation(db, userName);
        }
        ArrayList<ReservationDbModel> l = new ArrayList<>();
        if(cursor.moveToFirst()){
            do{
                int reservationID;String carName,finalPrice;
                reservationID = cursor.getInt(0);
                carName = cursor.getString(2);
                finalPrice = cursor.getString(5);
                l.add(new ReservationDbModel(reservationID,carName,finalPrice));

            }while (cursor.moveToNext());
        }
        viewReservationAdapter = new ViewReservationAdapter(this,0,l);
        listView.setAdapter(viewReservationAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ReservationDbModel reservationDbModel = (ReservationDbModel) parent.getItemAtPosition(position);
                int reservationID = reservationDbModel.getReservationID();
                Intent intent = new Intent(getApplicationContext(),SpecificReservationActivity.class);
                intent.putExtra("EXTRA_RESERVATION_ID",reservationID);
                startActivity(intent);
            }
        });
    }
}
