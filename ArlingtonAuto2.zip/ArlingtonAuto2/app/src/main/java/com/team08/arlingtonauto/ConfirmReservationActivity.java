package com.team08.arlingtonauto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ConfirmReservationActivity extends AppCompatActivity {
    private TextView carNameTextView;
    private TextView capacityTextView;
    private ImageView carImage;
    private TextView fromDateTextView;
    private TextView fromTime;
    private TextView toDateTextView;
    private TextView toTime;
    private TextView gps;
    private TextView onStar;
    private TextView siriusXM;
    private TextView finalPriceTextView;
    private boolean extras[];
    private double finalPrice;
    private String userName;
    private String carName;
    private String fromDate;
    private String toDate;
    ReservationDbManager reservationDbManager = new ReservationDbManager(this);
    DbManagerCar dbManagerCar = new DbManagerCar(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_reservation);
        carNameTextView = (TextView)findViewById(R.id.textView_car_name_cnfr);
        capacityTextView = (TextView)findViewById(R.id.textView_car_capacity_cnf);
        carImage = (ImageView) findViewById(R.id.imageView_car_image_confirm_rsv);
        fromDateTextView = (TextView)findViewById(R.id.textView_from_date_cnfr);
        fromTime = (TextView)findViewById(R.id.textView_from_time_cnfR);
        toDateTextView = (TextView)findViewById(R.id.textView_to_date_cnfr);
        toTime = (TextView)findViewById(R.id.textView_to_time_cnfr);
        gps = (TextView)findViewById(R.id.textView_Gps_selected);
        onStar = (TextView)findViewById(R.id.textView_onStar_Selected);
        siriusXM = (TextView)findViewById(R.id.textView_siriusXm_selected);
        finalPriceTextView = (TextView)findViewById(R.id.textView_final_price_cnfr);
        carNameTextView.setText(getIntent().getStringExtra("EXTRA_CAR_NAME"));
        carName = getIntent().getStringExtra("EXTRA_CAR_NAME");
        capacityTextView.setText(getIntent().getStringExtra("EXTRA_CAR_CAPACITY_CNF"));
        carImage.setImageResource(getIntent().getIntExtra("EXTRA_CAR_IMAGE",R.drawable.compact));
        fromDate = getIntent().getStringExtra("EXTRA_FROM_DATE_CNF");
        fromDateTextView.setText(getIntent().getStringExtra("EXTRA_FROM_DATE_CNF"));
        fromTime.setText(getIntent().getStringExtra("EXTRA_FROM_TIME_CNF"));
        toDateTextView.setText(getIntent().getStringExtra("EXTRA_TO_DATE_CNF"));
        toDate = getIntent().getStringExtra("EXTRA_TO_DATE_CNF");
        toTime.setText(getIntent().getStringExtra("EXTRA_TO_TIME_CNF"));
        extras = getIntent().getBooleanArrayExtra("EXTRA_ADD_ONS");
        finalPrice = getIntent().getDoubleExtra("EXTRA_FINAL_PRICE",169.88);
        finalPriceTextView.setText(Double.toString(finalPrice));
        userName = getIntent().getStringExtra("EXTRA_USER_NAME");
        if(extras[0]==true)
            gps.setText("YES");
        else
            gps.setText("NA");
        if(extras[1]==true)
            onStar.setText("YES");
        else
            onStar.setText("NA");
        if(extras[2]==true)
            siriusXM.setText("YES");
        else
            siriusXM.setText("NA");

        }
        public void onClickConfirmReservation(View view){
        boolean ins = reservationDbManager.reserveCar(userName,carName,fromDate,toDate,Double.toString(finalPrice));
            dbManagerCar.updateDateOnReservation(carName,fromDate,toDate);

            if(ins == true) {
                Toast.makeText(getApplicationContext(), "Reservation success!!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),ViewReservationActivity.class);
                intent.putExtra("FROM_CONFIRM",userName);
                startActivity(intent);
            }
            else{
                Toast.makeText(getApplicationContext(),"There was a problem with the reservation",Toast.LENGTH_SHORT).show();
            }

        }
}
