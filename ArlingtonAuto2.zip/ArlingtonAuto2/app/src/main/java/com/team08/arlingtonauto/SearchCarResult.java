package com.team08.arlingtonauto;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class SearchCarResult extends AppCompatActivity {


private Cursor cursor;
private CustomListAdaptor customListAdaptor;
private ListView listView;
DbManagerCar dbManagerCar;
SQLiteDatabase db;
private String fromDate,toDate,fromTime,toTime;
private String capacity;
private String userName;
private boolean fromManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_car_result);
        fromDate = getIntent().getStringExtra("EXTRA_FROM_DATE");
        fromTime = getIntent().getStringExtra("EXTRA_FROM_TIME");
        toDate = getIntent().getStringExtra("EXTRA_TO_DATE");
        toTime = getIntent().getStringExtra("EXTRA_TO_TIME");
        capacity = getIntent().getStringExtra("EXTRA_CAPACITY_SEARCH_CAR");
        userName = getIntent().getStringExtra("EXTRA_USER_NAME");
        fromManager = getIntent().getBooleanExtra("FROM_MANAGER_HOME",false);
        dbManagerCar = new DbManagerCar(getApplicationContext());
        listView = (ListView)findViewById(R.id.listViewID);
        ArrayList<SearchCarDbModel> l = new ArrayList<>();
        db = dbManagerCar.getReadableDatabase();
        if(fromManager==true){
            cursor = dbManagerCar.AvailabeCars(db);
        }
        else {
            cursor = dbManagerCar.searchCars(db, fromDate, fromTime, toDate, toTime, capacity);
        }

        if(cursor.moveToFirst()){
            do{
                String carName,carBasePrice;int cap,carImage;
                carName = cursor.getString(0);
                cap = cursor.getInt(1);
                switch (carName){
                    case "UltraSports":
                        carBasePrice = "$199.99";
                        carImage = R.drawable.ultrasports;
                        l.add(new SearchCarDbModel(cap,carName,carImage,carBasePrice));
                        break;
                    case "Smart":
                        carBasePrice = "32.99";
                        carImage = R.drawable.smart;
                        l.add(new SearchCarDbModel(cap,carName,carImage,carBasePrice));
                        break;
                    case "Economy":
                        carBasePrice = "39.99";
                        carImage = R.drawable.carimage1;
                        l.add(new SearchCarDbModel(cap,carName,carImage,carBasePrice));
                        break;
                    case "Compact":
                        carBasePrice = "44.99";
                        carImage = R.drawable.compact;
                        l.add(new SearchCarDbModel(cap,carName,carImage,carBasePrice));
                        break;
                    case "Intermediate":
                        carBasePrice = "45.99";
                        carImage = R.drawable.intermediate;
                        l.add(new SearchCarDbModel(cap,carName,carImage,carBasePrice));
                        break;
                    case "Standard":
                        carBasePrice = "48.99";
                        carImage = R.drawable.standard;
                        l.add(new SearchCarDbModel(cap,carName,carImage,carBasePrice));
                        break;
                    case "FullSize":
                        carBasePrice = "52.99";
                        carImage = R.drawable.fullsize;
                        l.add(new SearchCarDbModel(cap,carName,carImage,carBasePrice));
                        break;
                    case "SUV":
                        carBasePrice = "59.99";
                        carImage = R.drawable.suv;
                        l.add(new SearchCarDbModel(cap,carName,carImage,carBasePrice));
                        break;
                    case "MiniVan":
                        carBasePrice = "59.99";
                        carImage = R.drawable.minivan;
                        l.add(new SearchCarDbModel(cap,carName,carImage,carBasePrice));
                        break;


                }


            }while (cursor.moveToNext());


        }
        customListAdaptor = new CustomListAdaptor(this,0,l);
        listView.setAdapter(customListAdaptor);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                SearchCarDbModel searchCarDbModel = (SearchCarDbModel) parent.getItemAtPosition(position);
                String carName = searchCarDbModel.getCarName();
                int capacity = searchCarDbModel.getCapacity();
                int carImage = searchCarDbModel.getCarImage();
                String carBasePrice = searchCarDbModel.getCarBasePrice();
                Intent intent = new Intent(getApplicationContext(),ReserveCarActivity.class);
                intent.putExtra("EXTRA_CAR_NAME",carName);
                intent.putExtra("EXTRA_CAR_CAPACITY",capacity);
                intent.putExtra("EXTRA_CAR_IMAGE",carImage);
                intent.putExtra("Extra_CAR_BASE_PRICE",carBasePrice);
                intent.putExtra("EXTRA_USER_NAME",userName);
                startActivity(intent);

            }
        });
    }



}
